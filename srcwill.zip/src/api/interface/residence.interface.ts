export interface ResidenceInterface{
    idresidence: number,
    description: string
    
}