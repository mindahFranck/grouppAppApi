export interface QuartiersInterface{
    id: number,
    libelle: string
    
}