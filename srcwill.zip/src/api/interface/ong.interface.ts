export interface OngInterface{
    id: number,
    raisonSociale: string,
    
}