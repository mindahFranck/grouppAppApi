export interface CommunesInterface{
    codeCommunes: string,
    libelle: string
    
}