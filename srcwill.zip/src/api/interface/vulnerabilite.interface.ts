export interface VulnerabiliteInterface{
    idvulnerabilte: number,
    nom: string,
    description: string,

  }