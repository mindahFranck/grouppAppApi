export interface AgentsInterface{
    id: number,
    nom: string,
    prenoms: string,
    
}