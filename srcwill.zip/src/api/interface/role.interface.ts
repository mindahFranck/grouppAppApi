export interface RoleInterface{
    idrole: number,
    libelle: string,
    
}