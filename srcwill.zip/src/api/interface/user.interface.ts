export interface UserInterface {
    username: string;
    password: string;
    idrole: number;
  }
  export interface loginInterface{
    username: string;
    password: string;
  }